package unasat.datastructure.app.voertuiginitializer;

import unasat.datastructure.app.model.Voertuig;
import java.util.ArrayList;
import java.util.List;
import static unasat.datastructure.app.model.Wegdek.WEGDEK;

public class VoertuigInitializer {

    // Arrays
    public Voertuig[] initVoertuigenNoordArray() {
        return new Voertuig[]{
                new Voertuig(WEGDEK[0], 1, "PA 01-01"),
                new Voertuig(WEGDEK[0], 2, "PA 01-02"),
                new Voertuig(WEGDEK[0], 3, "Speciaal", "Ambulance met sirene", 3, "AM 99-01"),
                new Voertuig(WEGDEK[0], 4, "PA 01-03")
        };
    }

    public Voertuig[] initVoertuigenZuidArray() {
        return new Voertuig[]{
                new Voertuig(WEGDEK[1], 1, "PA 02-01"),
                new Voertuig(WEGDEK[1], 2, "PA 02-02"),
                new Voertuig(WEGDEK[1], 3, "PA 02-03"),
                new Voertuig(WEGDEK[1], 4, "PA 02-04"),
                new Voertuig(WEGDEK[1], 5, "PA 02-05"),
                new Voertuig(WEGDEK[1], 6, "PA 02-06"),
                new Voertuig(WEGDEK[1], 7, "PA 02-07"),
                new Voertuig(WEGDEK[1], 8, "PA 02-08"),
                new Voertuig(WEGDEK[1], 9, "PA 02-09"),
                new Voertuig(WEGDEK[1], 10, "PA 02-10"),
                new Voertuig(WEGDEK[1], 11, "PA 02-11"),
                new Voertuig(WEGDEK[1], 12, "PA 02-12"),
                new Voertuig(WEGDEK[1], 13, "PA 02-13"),
                new Voertuig(WEGDEK[1], 14, "PA 02-14"),
                new Voertuig(WEGDEK[1], 15, "PA 02-15"),
                new Voertuig(WEGDEK[1], 16, "PA 02-16"),
                new Voertuig(WEGDEK[1], 17, "Speciaal", "Brandweer met sirene", 2, "FB 99-02"),
                new Voertuig(WEGDEK[1], 18, "PA 02-17")
        };
    }

    public Voertuig[] initVoertuigenOostArray() {
        return new Voertuig[]{
                new Voertuig(WEGDEK[2], 1, "PA 03-01"),
                new Voertuig(WEGDEK[2], 2, "PA 03-02"),
                new Voertuig(WEGDEK[2], 3, "PA 03-03"),
                new Voertuig(WEGDEK[2], 4, "PA 03-04"),
                new Voertuig(WEGDEK[2], 5, "PA 03-05")
        };
    }

    public Voertuig[] initVoertuigenWestArray() {
        return new Voertuig[]{
                new Voertuig(WEGDEK[3], 1, "PA 04-01"),
                new Voertuig(WEGDEK[3], 2, "PA 04-02"),
                new Voertuig(WEGDEK[3], 3, "PA 04-03"),
                new Voertuig(WEGDEK[3], 4, "PA 04-04"),
                new Voertuig(WEGDEK[3], 5, "PA 04-05"),
                new Voertuig(WEGDEK[3], 6, "PA 04-06"),
                new Voertuig(WEGDEK[3], 7, "PA 04-07"),
                new Voertuig(WEGDEK[3], 8, "PA 04-08"),
                new Voertuig(WEGDEK[3], 9, "Speciaal", "Politie met sirene", 1, "PS 99-03"),
                new Voertuig(WEGDEK[3], 10, "PA 04-09"),
                new Voertuig(WEGDEK[3], 11, "PA 04-10"),
                new Voertuig(WEGDEK[3], 12, "PA 04-11"),
                new Voertuig(WEGDEK[3], 13, "PA 04-12"),
                new Voertuig(WEGDEK[3], 14, "PA 04-13")
        };
    }

    // ArrayLists
    public List<Voertuig> initVoertuigenNoordList() {
        List<Voertuig> voertuigenNoordList = new ArrayList<>();
        voertuigenNoordList.add(new Voertuig(WEGDEK[0], 1, "PA 01-01"));
        voertuigenNoordList.add(new Voertuig(WEGDEK[0], 2, "PA 01-02"));
        voertuigenNoordList.add(new Voertuig(WEGDEK[0], 3, "Speciaal", "Ambulance met sirene", 3, "AM 99-01"));
        voertuigenNoordList.add(new Voertuig(WEGDEK[0], 4, "PA 01-03"));
        return voertuigenNoordList;
    }

    public List<Voertuig> initVoertuigenZuidList() {
        List<Voertuig> voertuigenZuidList = new ArrayList<>();
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 1, "PA 02-01"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 2, "PA 02-02"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 3, "PA 02-03"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 4, "PA 02-04"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 5, "PA 02-05"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 6, "PA 02-06"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 7, "PA 02-07"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 8, "PA 02-08"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 9, "PA 02-09"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 10, "PA 02-10"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 11, "PA 02-11"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 12, "PA 02-12"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 13, "PA 02-13"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 14, "PA 02-14"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 15, "PA 02-15"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 16, "PA 02-16"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 17, "Speciaal", "Brandweer met sirene", 2, "FB 99-02"));
        voertuigenZuidList.add(new Voertuig(WEGDEK[1], 18, "PA 02-17"));
        return voertuigenZuidList;
    }
}