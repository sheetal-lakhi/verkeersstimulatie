package unasat.datastructure.app.model;

public class Voertuig {
    Wegdek wegdek;                                       //These variables describe vehicle's attributes
    private int nummer;
    private String type;
    private String naam;
    private String kentekenNummer;
    private int priority;

    public Voertuig(Wegdek wegdek, int nummer, String kentekenNummer) {              //constructor for class named Voertuig met parameters
        this.wegdek = wegdek;
        this.nummer = nummer;
        this.naam = "Auto" + nummer;
        this.kentekenNummer = kentekenNummer;
    }

    public Voertuig(Wegdek wegdek, int nummer, String type, String naam, int priority, String kentekenNummer) {
        this.wegdek = wegdek;
        this.nummer = nummer;
        this.type = type;
        this.naam = naam;
        this.priority = priority;
        this.kentekenNummer = kentekenNummer;
    }

    public Wegdek getWegdek() {
        return wegdek;
    }

    public void setWegdek(Wegdek wegdek) {
        this.wegdek = wegdek;
    }

    public int getNummer() {
        return nummer;
    }

    public void setNummer(int nummer) {
        this.nummer = nummer;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getKentekenNummer() {
        return kentekenNummer;
    }

    public void setKentekenNummer(String kentekenNummer) {
        this.kentekenNummer = kentekenNummer;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}
