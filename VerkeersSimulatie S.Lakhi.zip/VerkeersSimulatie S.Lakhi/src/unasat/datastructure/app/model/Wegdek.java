package unasat.datastructure.app.model;

public class Wegdek {
    private int wegdekNummer;
    private String wegdekNaam;

    public Wegdek(int wegdekNummer, String wegdekNaam) {
        this.wegdekNummer = wegdekNummer;
        this.wegdekNaam = wegdekNaam;
    }

    public int getWegdekNummer() {
        return wegdekNummer;
    }

    public void setwegdekNummer(int wegdekNummer) {
        this.wegdekNummer = wegdekNummer;
    }

    public String getWegdekNaam() {
        return wegdekNaam;
    }

    public void setWegdekNaam(String wegdekNaam) {
        this.wegdekNaam = wegdekNaam;
    }


    public static final Wegdek[] WEGDEK = {
            new Wegdek(1, "Noord"),
            new Wegdek(2, "Zuid"),
            new Wegdek(3, "Oost"),
            new Wegdek(4, "West")
    };
}
