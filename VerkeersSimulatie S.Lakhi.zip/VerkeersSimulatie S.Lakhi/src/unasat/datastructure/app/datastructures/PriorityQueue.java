package unasat.datastructure.app.datastructures;

import unasat.datastructure.app.model.Voertuig;

public class PriorityQueue {
    public class Node {
        private Voertuig voertuig;
        private int priority;
        private Node next;
        private Node prev;

        public Voertuig getData() {
            return voertuig;
        }

        public void setData(Voertuig voertuig) {
            this.voertuig = voertuig;
        }

        public int getPriority() {
            return priority;
        }

        public void setPriority(int priority) {
            this.priority = priority;
        }

        public Node getNext() {
            return next;
        }

        public void setNext(Node next) {
            this.next = next;
        }

        public Node getPrev() {
            return prev;
        }

        public void setPrev(Node prev) {
            this.prev = prev;
        }
    }

    private Node head;
    private int totalSize;

    public PriorityQueue() {
        head = null;
        totalSize = 0;
    }

    public void insert(Voertuig voertuig) {
        Node nd = new Node();
        nd.setData(voertuig);
        nd.setPriority(voertuig.getPriority());

        if (head == null) {
            head = nd;
        } else {
            nd.setNext(head);
            head.setPrev(nd);
            head = nd;
        }

        totalSize++;
    }

    public Voertuig remove() {
        Node temp = head;
        (head) = (head).next;
        totalSize--;
        return temp.voertuig;
    }

    public boolean isEmpty() {
        return (totalSize == 0);
    }
}
