package unasat.datastructure.app.datastructures;

import unasat.datastructure.app.model.Voertuig;

public class Stack {

    public class Node {
        Voertuig voertuig;
        Node next;

        public Node(Voertuig voertuig) {
            this.voertuig = voertuig;
        }

    }

    private int size;
    private Node head;

    public Stack() {
        size = 0;
        head = null;
    }


    public boolean isEmpty() {
        return size == 0;
    }

    public void push(Voertuig voertuig) {
        Node newNode = new Node(voertuig);
        if (head == null) {
            head = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
        size++;
    }

    public Voertuig pop() {
        if (head == null) return null;

        Node n = head;
        head = head.next;
        size--;

        return n.voertuig;
    }
}

