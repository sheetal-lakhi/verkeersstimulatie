package unasat.datastructure.app.datastructures;

import unasat.datastructure.app.model.Voertuig;

public class Queue {

    private Node front, rear;
    private int currentSize; // number of items

    //class to define linked node
    private class Node {
        Voertuig voertuig;
        Node next;
    }

    //Zero argument constructor
    public Queue() {
        front = null;
        rear = null;
        currentSize = 0;
    }

    //Remove item from the beginning of the list.
    public Voertuig dequeue() {
        Voertuig voertuig = front.voertuig;
        front = front.next;
        if (isEmpty()) {
            rear = null;
        }
        currentSize--;
        return voertuig;
    }

    //Add data to the end of the list.
    public void enqueue(Voertuig voertuig) {
        Node oldRear = rear;
        rear = new Node();
        rear.voertuig = voertuig;
        rear.next = null;
        if (isEmpty()) {
            front = rear;
        } else {
            oldRear.next = rear;
        }
        currentSize++;
    }

    public int getnItems() {
        return currentSize;
    }

    public boolean isEmpty() {
        return (currentSize == 0);
    }


}


