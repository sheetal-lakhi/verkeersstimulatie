package unasat.datastructure.app;

import unasat.datastructure.app.model.Voertuig;
import unasat.datastructure.app.service.VerkeersSimulatieService;
import unasat.datastructure.app.voertuiginitializer.VoertuigInitializer;

import java.util.Arrays;
import java.util.List;

public class App {
    public static void main(String[] args) {
        VoertuigInitializer initializer = new VoertuigInitializer();

        List<Voertuig> voertuigenNoordList = Arrays.asList(initializer.initVoertuigenNoordArray());
        List<Voertuig> voertuigenZuidList = Arrays.asList(initializer.initVoertuigenZuidArray());
        List<Voertuig> voertuigenOostList = Arrays.asList(initializer.initVoertuigenOostArray());
        List<Voertuig> voertuigenWestList = Arrays.asList(initializer.initVoertuigenWestArray());

        VerkeersSimulatieService verkeersSimulatieService = new VerkeersSimulatieService();
        verkeersSimulatieService.prioritizeVoertuigen(voertuigenNoordList, voertuigenZuidList, voertuigenOostList, voertuigenWestList);
    }
}
